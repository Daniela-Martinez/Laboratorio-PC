#!/bin/bash
# -*- ENCODING: UTF-8 -*-
echo "IP privada" >> datos.txt
echo "#Tomar solo la direccion que esta despues de 'src'" >> datos.txt
ip route >> datos.txt

echo "\nIP publica" >> datos.txt
curl ifconfig.me >> datos.txt

echo "\nIP address" >> datos.txt
curl bot.whatismyipaddress.com >> datos.txt

echo "\nHostname" >> datos.txt
hostname -I >> datos.txt

echo "\nnmap a segmento de red privado" >> datos.txt
nmap 192.168.130.129 >> datos.txt

echo "\nnmap a pagina web" >> datos.txt
nmap --script http-headers scanme.nmap.org >> datos.txt

echo "\nnmap hacia la IP publica" >> datos.txt
ipPub=$(curl ifconfig.me)
nmap $ipPub >> datos.txt

#Codificar
base64 < datos.txt > Resultados-7.txt


