﻿$modulo=Get-Module -Name Practica-4
option